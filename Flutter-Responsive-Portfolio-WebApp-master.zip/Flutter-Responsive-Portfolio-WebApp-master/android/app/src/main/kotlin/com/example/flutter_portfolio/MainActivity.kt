package com.example.flutter_portfolio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
