import 'package:flutter/material.dart';

final PageController controller=PageController();